from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events, register_job
import requests
from aylienapiclient import textapi
import logging
import traceback
from hackernews.models import Topstoryinfo
from .settings import APP_ID, APP_KEY


scheduler = BackgroundScheduler()
scheduler.add_jobstore(DjangoJobStore(), "default")

logging = logging.getLogger('__name__')
client = textapi.Client(APP_ID,APP_KEY)

#auto calling in bg every 30 $econds *_*

@register_job(scheduler, "interval", minutes=45, replace_existing=True)
def fetch_new_stories_job():
	#getting top stories $$
	top_story_url = "https://hacker-news.firebaseio.com/v0/topstories.json"
	top_story_payload = "{}"
	top_story_ids = requests.request("GET", top_story_url, data=top_story_payload)
	top_story_ids = top_story_ids.text[1:-1].split(',')

# new entry to be store in DB *_*
diff_list= list(set(top_story_ids) - set(stored_story_ids))

# M storing only that stories that are not on DB
for item_id in diff_list:
	try:
		item_url = "https://hacker-news.firebaseio.com/v0/item/{0}.json".format(item_id)
		item_payload = "{}"
		response = requests.request("GET", item_url, data=item_payload).json()

		create_top_story = Topstoryinfo(story_id= response.get('id'),
			username = response.get('by'),
			title= response.get('title'),
			url = response.get('url'),
			score= response.get('score'),
			story_type = response.get('type'),
			sentiment= client.Sentiment({'text':response.get('title')}).get('polarity'),
			)
		create_top_story.save()
		logging.debug('saved data for story_id {}'.format(item_id))
	except Exception as e:
		logging.error("Exception Occured during story_id = {}".format(item_id), exc_info= True)


register_events(scheduler)
scheduler.start()

