from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import logging
from aylienapiclient import textapi
import requests

logging = logging.getLogger('__name__')
# Create your views here.

def index(request):
	if request.method == 'GET':
		search_query == request.GET.get('search_box',None)

		# getting top stories !@#$%^&*()

		top_story_url = "https://hacker-news.firebaseio.com/v0/topstories.json"
		top_story_payload = "{}"
		top_story_id = requests.request("GET", top_story_url, data=top_story_payload)
		top_story_ids= top_story_ids.text[1:-1].split(',')

		# getting title and sentiment for store in DB

		show_top_story_list = []
		for item_id in top_story_ids:
			try:
				story = Topstoryinfo.objects.get(story_id='{0}'.format(item_id))
				show_top_story_list.append({'title':story.title,'sentiment':story.sentiment,})
			except Exception as e:
				logging.error("Record not found for story: {0}".format(item_id),exc_info=True)
		return render(request,'templates/index.html',{'stories_list':show_top_story_list})	
	else:
		return JsonResponse({'code':0})

@csrf_exempt
def partial_search(request):
	if 'word' in request.GET:
		word=request.GET.get('word')
		searched_stories = []

		#searching top stories info for any matching reasult

		stories = Topstoryinfo.objects.filter(title_icontain=word)
		for row in stories:
			searched_stories.append({'title':row.title,'sentiment':row.sentiment})
		searched_stories = searched_stories[1:-1]
		return JsonResponse({'data':searched_stories})
	else:
		return JsonResponse({'code':0})		






#from hn import HN

#hn = HN()

# print top 10 stories from homepage
#for story in hn.get_top_stories()[:10]:
 #   story.print_story()
  #  print '*' * 50
   # print ''
