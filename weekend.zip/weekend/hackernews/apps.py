from django.apps import AppConfig


class HackernewsConfig(AppConfig):
    name = 'hackernews'
