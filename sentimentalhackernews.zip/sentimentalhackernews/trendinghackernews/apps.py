from django.apps import AppConfig


class TrendinghackernewsConfig(AppConfig):
    name = 'trendinghackernews'
