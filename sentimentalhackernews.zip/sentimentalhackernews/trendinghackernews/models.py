from django.db import models

# Create your models here.

class Topstoryinfo(models.Model):
    story_id = models.CharField(unique=True, max_length=10)
    username = models.CharField(max_length=45, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    url = models.CharField(max_length=2000, blank=True, null=True)
    score = models.CharField(max_length=10, blank=True, null=True)
    story_desc = models.CharField(max_length=245, blank=True, null=True)
    story_type = models.CharField(max_length=10, blank=True, null=True)
    time = models.CharField(max_length=10, blank=True, null=True)
    sentiment = models.CharField(max_length=10, blank=True, null=True)
    istrending = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'topstoryinfo'